import fetch from 'isomorphic-unfetch';

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();

  const OPENAI_KEY = process.env.OPENAI_API_KEY;
  const MODEL = process.env.MODEL_NAME || 'gpt-4o-mini';

  if (!OPENAI_KEY) {
    return res.status(500).json({ error: 'Sunucu yapılandırılmamış: OPENAI_API_KEY eksik.' });
  }

  try {
    const body = req.body;
    // Normalize messages to OpenAI chat format
    const messages = (body.messages || []).map(m => ({ role: m.role, content: m.content }));

    const payload = {
      model: MODEL,
      messages: messages,
      max_tokens: 800
    };

    const r = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${OPENAI_KEY}`
      },
      body: JSON.stringify(payload)
    });

    if (!r.ok) {
      const txt = await r.text();
      return res.status(500).json({ error: txt });
    }
    const j = await r.json();
    const reply = j.choices?.[0]?.message?.content || j.output?.[0]?.content?.[0]?.text || '';
    res.status(200).json({ reply });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message || String(err) });
  }
}

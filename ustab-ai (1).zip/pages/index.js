import { useState } from 'react';

export default function Home() {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState([{ id: 1, role: 'assistant', text: 'Merhaba! Üstâb AI'ya hoş geldin.' }]);
  const [loading, setLoading] = useState(false);

  async function sendMessage(e) {
    e?.preventDefault();
    if (!input.trim()) return;
    const userMsg = { id: Date.now(), role: 'user', text: input };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setLoading(true);

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: [...messages, userMsg].map(m => ({ role: m.role, content: m.text })) })
      });
      const data = await res.json();
      const assistantMsg = { id: Date.now()+1, role: 'assistant', text: data.reply || 'Yanıt alınamadı.'};
      setMessages(prev => [...prev, assistantMsg]);
    } catch (err) {
      setMessages(prev => [...prev, { id: Date.now()+2, role: 'assistant', text: 'Hata: ' + (err.message||err) }]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={{fontFamily:'Inter, system-ui, sans-serif', display:'flex', justifyContent:'center', padding:20}}>
      <div style={{width:720, border:'1px solid #e6e6e6', borderRadius:12, overflow:'hidden', boxShadow:'0 6px 24px rgba(15,23,42,0.08)'}}>
        <header style={{padding:16, borderBottom:'1px solid #eee', background:'#0f172a', color:'white'}}>
          <h1 style={{margin:0}}>Üstâb AI</h1>
          <div style={{fontSize:13, opacity:0.85}}>Her soruya ustalıkla yanıt verir.</div>
        </header>

        <main style={{height:520, padding:16, overflowY:'auto', background:'#f8fafc'}}>
          {messages.map(m => (
            <div key={m.id} style={{display:'flex', justifyContent: m.role==='user' ? 'flex-end' : 'flex-start', marginBottom:12}}>
              <div style={{
                maxWidth:'70%',
                padding:12,
                borderRadius:12,
                background: m.role==='user' ? '#0ea5a3' : 'white',
                color: m.role==='user' ? 'white' : '#0f172a',
                boxShadow:'0 1px 2px rgba(0,0,0,0.04)'
              }}>
                <div style={{whiteSpace:'pre-wrap'}}>{m.text}</div>
                <div style={{fontSize:11, opacity:0.6, marginTop:6}}>{m.role}</div>
              </div>
            </div>
          ))}
        </main>

        <form onSubmit={sendMessage} style={{display:'flex', gap:8, padding:12, borderTop:'1px solid #eee', background:'white'}}>
          <textarea value={input} onChange={e=>setInput(e.target.value)} rows={1} style={{flex:1, padding:10, borderRadius:8, border:'1px solid #e6e6e6'}} placeholder="Bir şey yaz..."/>
          <button disabled={loading} style={{padding:'8px 14px', borderRadius:8, background:'#0f172a', color:'white', border:'none'}}>{loading ? 'Gönderiliyor...' : 'Gönder'}</button>
        </form>
      </div>
    </div>
  );
}

# Üstâb AI — Deploy-ready Next.js Chat App (Vercel)

Bu proje **Üstâb AI** için minimal, Vercel'e kolayca deploy edilebilen bir Next.js uygulamasıdır.
Backend, OpenAI API'sine /api/chat route'u üzerinden proxy yapacak şekilde ayarlanmıştır.

## Hızlı kurulum (Vercel - en kolay)
1. GitHub'a bu klasörü gönderin (repo oluşturun) veya ZIP'i açın.
2. Vercel hesabınıza giriş yapın → New Project → Import from GitHub.
3. Repository seçildikten sonra Environment Variables ekleyin:
   - `OPENAI_API_KEY` = sk-...
   - `MODEL_NAME` = gpt-4o-mini
4. Deploy butonuna basın. Site `<your-project>.vercel.app` altında hazır olur.
5. İlk test için siteye gidip mesaj gönderin.

## Lokal çalıştırma
```bash
npm install
npm run dev
# localhost:3000 aç
```

## Güvenlik notları
- API anahtarını kesinlikle kimseyle paylaşmayın.
- Üretimde rate limiting, authentication ve usage caps ekleyin.
